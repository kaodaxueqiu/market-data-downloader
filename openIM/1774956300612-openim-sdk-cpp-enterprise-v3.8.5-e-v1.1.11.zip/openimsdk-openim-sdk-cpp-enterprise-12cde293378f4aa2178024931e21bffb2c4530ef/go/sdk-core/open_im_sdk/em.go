// Copyright © 2023 OpenIM SDK. All rights reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package open_im_sdk

import (
	"context"
	"errors"

	"github.com/openimsdk/openim-sdk-core/v3/open_im_sdk_callback"
	"github.com/openimsdk/tools/log"
)

var ErrNotImplemented = errors.New("not set listener")

type emptyGroupListener struct {
	ctx context.Context
}

func newEmptyGroupListener(ctx context.Context) open_im_sdk_callback.OnGroupListener {
	return &emptyGroupListener{ctx}
}

func (e *emptyGroupListener) OnJoinedGroupAdded(groupInfo string) {
	log.ZWarn(e.ctx, "GroupListener is not implemented", nil, "groupInfo", groupInfo)
}

func (e *emptyGroupListener) OnJoinedGroupDeleted(groupInfo string) {
	log.ZWarn(e.ctx, "GroupListener is not implemented", nil, "groupInfo", groupInfo)

}

func (e *emptyGroupListener) OnGroupMemberAdded(groupMemberInfo string) {
	log.ZWarn(e.ctx, "GroupListener is not implemented", nil, "groupMemberInfo", groupMemberInfo)

}

func (e *emptyGroupListener) OnGroupMemberDeleted(groupMemberInfo string) {
	log.ZWarn(e.ctx, "GroupListener is not implemented", nil, "groupMemberInfo", groupMemberInfo)

}

func (e *emptyGroupListener) OnGroupApplicationAdded(groupApplication string) {
	log.ZWarn(e.ctx, "GroupListener is not implemented", nil, "groupApplication", groupApplication)

}

func (e *emptyGroupListener) OnGroupApplicationDeleted(groupApplication string) {
	log.ZWarn(e.ctx, "GroupListener is not implemented", nil, "groupApplication", groupApplication)

}

func (e *emptyGroupListener) OnGroupInfoChanged(groupInfo string) {
	log.ZWarn(e.ctx, "GroupListener is not implemented", nil, "groupInfo", groupInfo)

}

func (e *emptyGroupListener) OnGroupDismissed(groupInfo string) {
	log.ZWarn(e.ctx, "GroupListener is not implemented", nil, "groupInfo", groupInfo)
}

func (e *emptyGroupListener) OnGroupMemberInfoChanged(groupMemberInfo string) {
	log.ZWarn(e.ctx, "GroupListener is not implemented", nil, "groupMemberInfo", groupMemberInfo)
}

func (e *emptyGroupListener) OnGroupApplicationAccepted(groupApplication string) {
	log.ZWarn(e.ctx, "GroupListener is not implemented", nil, "groupApplication", groupApplication)
}

func (e *emptyGroupListener) OnGroupApplicationRejected(groupApplication string) {
	log.ZWarn(e.ctx, "GroupListener is not implemented", nil, "groupApplication", groupApplication)
}

type emptyFriendshipListener struct {
	ctx context.Context
}

func newEmptyFriendshipListener(ctx context.Context) open_im_sdk_callback.OnFriendshipListener {
	return &emptyFriendshipListener{ctx}
}

func (e *emptyFriendshipListener) OnFriendApplicationAdded(friendApplication string) {
	log.ZWarn(e.ctx, "FriendshipListener is not implemented", nil,
		"friendApplication", friendApplication)
}

func (e *emptyFriendshipListener) OnFriendApplicationDeleted(friendApplication string) {
	log.ZWarn(e.ctx, "FriendshipListener is not implemented", nil,
		"friendApplication", friendApplication)
}

func (e *emptyFriendshipListener) OnFriendApplicationAccepted(friendApplication string) {
	log.ZWarn(e.ctx, "FriendshipListener is not implemented", nil,
		"friendApplication", friendApplication)
}

func (e *emptyFriendshipListener) OnFriendApplicationRejected(friendApplication string) {
	log.ZWarn(e.ctx, "FriendshipListener is not implemented", nil,
		"friendApplication", friendApplication)
}

func (e *emptyFriendshipListener) OnFriendAdded(friendInfo string) {
	log.ZWarn(e.ctx, "FriendshipListener is not implemented", nil,
		"friendInfo", friendInfo)
}

func (e *emptyFriendshipListener) OnFriendDeleted(friendInfo string) {
	log.ZWarn(e.ctx, "FriendshipListener is not implemented", nil,
		"friendInfo", friendInfo)
}

func (e *emptyFriendshipListener) OnFriendInfoChanged(friendInfo string) {
	log.ZWarn(e.ctx, "FriendshipListener is not implemented", nil,
		"friendInfo", friendInfo)
}

func (e *emptyFriendshipListener) OnBlackAdded(blackInfo string) {
	log.ZWarn(e.ctx, "FriendshipListener is not implemented", nil,
		"blackInfo", blackInfo)
}

func (e *emptyFriendshipListener) OnBlackDeleted(blackInfo string) {
	log.ZWarn(e.ctx, "FriendshipListener is not implemented", nil,
		"blackInfo", blackInfo)
}

type emptyConversationListener struct {
	ctx context.Context
}

func newEmptyConversationListener(ctx context.Context) open_im_sdk_callback.OnConversationListener {
	return &emptyConversationListener{ctx: ctx}
}

func (e *emptyConversationListener) OnSyncServerStart(reinstalled bool) {
	log.ZWarn(e.ctx, "ConversationListener is not implemented", nil, "reinstalled", reinstalled)
}

func (e *emptyConversationListener) OnSyncServerProgress(progress int) {
	log.ZWarn(e.ctx, "ConversationListener is not implemented", nil, "progress", progress)
}

func (e *emptyConversationListener) OnSyncServerFinish(reinstalled bool) {
	log.ZWarn(e.ctx, "ConversationListener is not implemented", nil, "reinstalled", reinstalled)

}

func (e *emptyConversationListener) OnSyncServerFailed(reinstalled bool) {
	log.ZWarn(e.ctx, "ConversationListener is not implemented", nil, "reinstalled", reinstalled)
}

func (e *emptyConversationListener) OnNewConversation(conversationList string) {
	log.ZWarn(e.ctx, "ConversationListener is not implemented", nil, "conversationList", conversationList)
}

func (e *emptyConversationListener) OnConversationChanged(conversationList string) {
	log.ZWarn(e.ctx, "ConversationListener is not implemented", nil, "conversationList", conversationList)
}

func (e *emptyConversationListener) OnTotalUnreadMessageCountChanged(totalUnreadCount int32) {
	log.ZWarn(e.ctx, "ConversationListener is not implemented", nil, "totalUnreadCount", totalUnreadCount)
}

func (e *emptyConversationListener) OnConversationUserInputStatusChanged(change string) {
	log.ZWarn(e.ctx, "ConversationListener is not implemented", nil, "change", change)
}

type emptyAdvancedMsgListener struct {
	ctx context.Context
}

func newEmptyAdvancedMsgListener(ctx context.Context) open_im_sdk_callback.OnAdvancedMsgListener {
	return &emptyAdvancedMsgListener{ctx}
}

func (e *emptyAdvancedMsgListener) OnRecvOnlineOnlyMessage(message string) {

}

func (e *emptyAdvancedMsgListener) OnRecvNewMessage(message string) {
	log.ZWarn(e.ctx, "AdvancedMsgListener is not implemented OnRecvNewMessage", nil, "message", message)
}

func (e *emptyAdvancedMsgListener) OnRecvC2CReadReceipt(msgReceiptList string) {

	log.ZWarn(e.ctx, "AdvancedMsgListener is not implemented", nil,
		"msgReceiptList", msgReceiptList)
}

func (e *emptyAdvancedMsgListener) OnRecvGroupReadReceipt(groupMsgReceiptList string) {
	log.ZWarn(e.ctx, "AdvancedMsgListener is not implemented", nil,
		"groupMsgReceiptList", groupMsgReceiptList)
}

func (e *emptyAdvancedMsgListener) OnNewRecvMessageRevoked(messageRevoked string) {
	log.ZWarn(e.ctx, "AdvancedMsgListener is not implemented", nil, "messageRevoked", messageRevoked)
}

func (e *emptyAdvancedMsgListener) OnMsgEdited(msg string) {
	log.ZWarn(e.ctx, "OnMsgEdited is not implemented", nil, "msg", msg)
}

func (e *emptyAdvancedMsgListener) OnRecvMessageExtensionsChanged(msgID string, reactionExtensionList string) {
	log.ZWarn(e.ctx, "AdvancedMsgListener is not implemented", nil, "msgID", msgID,
		"reactionExtensionList", reactionExtensionList)
}

func (e *emptyAdvancedMsgListener) OnRecvMessageExtensionsDeleted(msgID string, reactionExtensionKeyList string) {
	log.ZWarn(e.ctx, "AdvancedMsgListener is not implemented", nil, "msgID", msgID,
		"reactionExtensionKeyList", reactionExtensionKeyList)
}

func (e *emptyAdvancedMsgListener) OnRecvMessageExtensionsAdded(msgID string, reactionExtensionList string) {
	log.ZWarn(e.ctx, "AdvancedMsgListener is not implemented", nil, "msgID", msgID,
		"reactionExtensionList", reactionExtensionList)
}

func (e *emptyAdvancedMsgListener) OnRecvOfflineNewMessage(message string) {
	log.ZWarn(e.ctx, "AdvancedMsgListener is not implemented", nil, "message", message)
}

func (e *emptyAdvancedMsgListener) OnMsgDeleted(message string) {
	log.ZWarn(e.ctx, "AdvancedMsgListener is not implemented", nil, "message", message)
}

func (e *emptyAdvancedMsgListener) OnMessageModified(message string) {
	log.ZWarn(e.ctx, "AdvancedMsgListener is not implemented", nil, "message", message)
}

func (e *emptyAdvancedMsgListener) OnChangedPinnedMsg(message string) {
	log.ZWarn(e.ctx, "AdvancedMsgListener is not implemented", nil, "message", message)
}

func (e *emptyAdvancedMsgListener) OnDeleteUserAllMsgsInConv(message string) {
	log.ZWarn(e.ctx, "OnDeleteUserAllMsgsInConv is not implemented", nil, "message", message)
}

type emptyBatchMsgListener struct{}

func newEmptyBatchMsgListener() *emptyBatchMsgListener {
	return &emptyBatchMsgListener{}
}

func (e *emptyBatchMsgListener) OnRecvNewMessages(messageList string) {

}

func (e *emptyBatchMsgListener) OnRecvOfflineNewMessages(messageList string) {

}

type emptyUserListener struct {
	ctx context.Context
}

func newEmptyUserListener(ctx context.Context) open_im_sdk_callback.OnUserListener {
	return &emptyUserListener{ctx: ctx}
}

func (e *emptyUserListener) OnSelfInfoUpdated(userInfo string) {
	log.ZWarn(e.ctx, "UserListener is not implemented", nil, "userInfo", userInfo)
}

func (e *emptyUserListener) OnUserStatusChanged(statusMap string) {
	log.ZWarn(e.ctx, "UserListener is not implemented", nil, "statusMap", statusMap)
}

type emptyCustomBusinessListener struct {
	ctx context.Context
}

func newEmptyCustomBusinessListener(ctx context.Context) open_im_sdk_callback.OnCustomBusinessListener {
	return &emptyCustomBusinessListener{ctx: ctx}
}

func (e *emptyCustomBusinessListener) OnRecvCustomBusinessMessage(businessMessage string) {
	log.ZWarn(e.ctx, "CustomBusinessListener is not implemented", nil,
		"businessMessage", businessMessage)

}

type emptySignalingListener struct {
	ctx context.Context
}

func newEmptySignalingListener(ctx context.Context) open_im_sdk_callback.OnSignalingListener {
	return &emptySignalingListener{ctx: ctx}
}

func (e *emptySignalingListener) OnReceiveNewInvitation(receiveNewInvitationCallback string) {
	log.ZWarn(e.ctx, "SignalingListener is not implemented", nil, "receiveNewInvitationCallback",
		receiveNewInvitationCallback)
}

func (e *emptySignalingListener) OnInviteeAccepted(inviteeAcceptedCallback string) {
	log.ZWarn(e.ctx, "SignalingListener is not implemented", nil, "inviteeAcceptedCallback",
		inviteeAcceptedCallback)
}

func (e *emptySignalingListener) OnInviteeAcceptedByOtherDevice(inviteeAcceptedCallback string) {
	log.ZWarn(e.ctx, "SignalingListener is not implemented", nil, "inviteeAcceptedCallback",
		inviteeAcceptedCallback)
}

func (e *emptySignalingListener) OnInviteeRejected(inviteeRejectedCallback string) {
	log.ZWarn(e.ctx, "SignalingListener is not implemented", nil, "inviteeRejectedCallback",
		inviteeRejectedCallback)
}

func (e *emptySignalingListener) OnInviteeRejectedByOtherDevice(inviteeRejectedCallback string) {
	log.ZWarn(e.ctx, "SignalingListener is not implemented", nil, "inviteeRejectedCallback",
		inviteeRejectedCallback)
}

func (e *emptySignalingListener) OnInvitationCancelled(invitationCancelledCallback string) {
	log.ZWarn(e.ctx, "SignalingListener is not implemented", nil, "invitationCancelledCallback",
		invitationCancelledCallback)
}

func (e *emptySignalingListener) OnInvitationTimeout(invitationTimeoutCallback string) {
	log.ZWarn(e.ctx, "SignalingListener is not implemented", nil, "invitationTimeoutCallback",
		invitationTimeoutCallback)
}

func (e *emptySignalingListener) OnHangUp(hangUpCallback string) {
	log.ZWarn(e.ctx, "SignalingListener is not implemented", nil, "hangUpCallback",
		hangUpCallback)
}

func (e *emptySignalingListener) OnRoomParticipantConnected(onRoomParticipantConnectedCallback string) {
	log.ZWarn(e.ctx, "SignalingListener is not implemented", nil, "onRoomParticipantConnectedCallback",
		onRoomParticipantConnectedCallback)
}

func (e *emptySignalingListener) OnRoomParticipantDisconnected(onRoomParticipantDisconnectedCallback string) {
	log.ZWarn(e.ctx, "SignalingListener is not implemented", nil, "onRoomParticipantDisconnectedCallback",
		onRoomParticipantDisconnectedCallback)
}

func (e *emptySignalingListener) OnStreamChange(OnStreamChangeCallback string) {
	log.ZWarn(e.ctx, "SignalingListener is not implemented", nil, "OnStreamChangeCallback",
		OnStreamChangeCallback)
}

func (e *emptySignalingListener) OnReceiveCustomSignal(CustomSignalCallback string) {
	log.ZWarn(e.ctx, "SignalingListener is not implemented", nil, "CustomSignalCallback",
		CustomSignalCallback)
}

type emptyForServiceListener struct {
	ctx context.Context
}

func newEmptyForServiceListener(ctx context.Context) open_im_sdk_callback.OnListenerForService {
	return &emptyForServiceListener{ctx: ctx}
}

func (e *emptyForServiceListener) OnGroupApplicationAdded(groupApplication string) {
	log.ZWarn(e.ctx, "ForServiceListener is not implemented", nil,
		"groupApplication", groupApplication)
}

func (e *emptyForServiceListener) OnGroupApplicationAccepted(groupApplication string) {
	log.ZWarn(e.ctx, "ForServiceListener is not implemented", nil,
		"groupApplication", groupApplication)
}

func (e *emptyForServiceListener) OnFriendApplicationAdded(friendApplication string) {
	log.ZWarn(e.ctx, "ForServiceListener is not implemented", nil,
		"friendApplication", friendApplication)
}

func (e *emptyForServiceListener) OnFriendApplicationAccepted(groupApplication string) {
	log.ZWarn(e.ctx, "ForServiceListener is not implemented", nil,
		"groupApplication", groupApplication)
}

func (e *emptyForServiceListener) OnReceiveNewInvitation(receiveNewInvitationCallback string) {
	log.ZWarn(e.ctx, "ForServiceListener is not implemented", nil,
		"receiveNewInvitationCallback", receiveNewInvitationCallback)
}

func (e *emptyForServiceListener) OnInviteeAccepted(inviteeAcceptedCallback string) {
	log.ZWarn(e.ctx, "ForServiceListener is not implemented", nil,
		"inviteeAcceptedCallback", inviteeAcceptedCallback)
}

func (e *emptyForServiceListener) OnInviteeAcceptedByOtherDevice(inviteeAcceptedCallback string) {
	log.ZWarn(e.ctx, "ForServiceListener is not implemented", nil,
		"inviteeAcceptedCallback", inviteeAcceptedCallback)
}

func (e *emptyForServiceListener) OnInviteeRejected(inviteeRejectedCallback string) {
	log.ZWarn(e.ctx, "ForServiceListener is not implemented", nil,
		"inviteeRejectedCallback", inviteeRejectedCallback)
}

func (e *emptyForServiceListener) OnInviteeRejectedByOtherDevice(inviteeRejectedCallback string) {
	log.ZWarn(e.ctx, "ForServiceListener is not implemented", nil,
		"inviteeRejectedCallback", inviteeRejectedCallback)
}

func (e *emptyForServiceListener) OnInvitationCancelled(invitationCancelledCallback string) {
	log.ZWarn(e.ctx, "ForServiceListener is not implemented", nil,
		"invitationCancelledCallback", invitationCancelledCallback)
}

func (e *emptyForServiceListener) OnInvitationTimeout(invitationTimeoutCallback string) {
	log.ZWarn(e.ctx, "ForServiceListener is not implemented", nil,
		"invitationTimeoutCallback", invitationTimeoutCallback)
}

func (e *emptyForServiceListener) OnHangUp(hangUpCallback string) {
	log.ZWarn(e.ctx, "ForServiceListener is not implemented", nil,
		"hangUpCallback", hangUpCallback)
}

func (e *emptyForServiceListener) OnRoomParticipantConnected(onRoomParticipantConnectedCallback string) {
	log.ZWarn(e.ctx, "ForServiceListener is not implemented", nil,
		"onRoomParticipantConnectedCallback", onRoomParticipantConnectedCallback)
}

func (e *emptyForServiceListener) OnRoomParticipantDisconnected(onRoomParticipantDisconnectedCallback string) {
	log.ZWarn(e.ctx, "ForServiceListener is not implemented", nil,
		"onRoomParticipantDisconnectedCallback", onRoomParticipantDisconnectedCallback)
}

func (e *emptyForServiceListener) OnStreamChange(OnStreamChangeCallback string) {
	log.ZWarn(e.ctx, "ForServiceListener is not implemented", nil,
		"OnStreamChangeCallback", OnStreamChangeCallback)
}

func (e *emptyForServiceListener) OnReceiveCustomSignal(CustomSignalCallback string) {
	log.ZWarn(e.ctx, "ForServiceListener is not implemented", nil,
		"CustomSignalCallback", CustomSignalCallback)
}

type emptyConversationGroupListener struct {
	ctx context.Context
}

func newEmptyConversationGroupListener(ctx context.Context) open_im_sdk_callback.OnConversationGroupListener {
	return &emptyConversationGroupListener{ctx: ctx}
}

func (e *emptyConversationGroupListener) OnConversationGroupAdded(conversationGroupList string) {
	log.ZWarn(e.ctx, "OnConversationGroupAdded", nil, "CustomConversationGroupListCallback", conversationGroupList)
}

func (e *emptyConversationGroupListener) OnConversationGroupDeleted(conversationGroupList string) {
	log.ZWarn(e.ctx, "OnConversationGroupDeleted", nil, "CustomConversationGroupListCallback", conversationGroupList)
}

func (e *emptyConversationGroupListener) OnConversationGroupChanged(conversationGroupList string) {
	log.ZWarn(e.ctx, "OnConversationGroupChanged", nil, "CustomConversationGroupListCallback", conversationGroupList)
}

func (e *emptyConversationGroupListener) OnConversationGroupMemberAdded(conversationList string) {
	log.ZWarn(e.ctx, "OnConversationGroupMemberAdded", nil, "CustomConversationGroupMemberCallback", conversationList)
}

func (e *emptyConversationGroupListener) OnConversationGroupMemberDeleted(conversationList string) {
	log.ZWarn(e.ctx, "OnConversationGroupMemberDeleted", nil, "CustomConversationGroupMemberCallback", conversationList)
}
