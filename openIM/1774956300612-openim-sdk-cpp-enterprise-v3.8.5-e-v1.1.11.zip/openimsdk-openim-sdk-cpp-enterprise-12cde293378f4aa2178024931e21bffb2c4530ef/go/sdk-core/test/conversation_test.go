// Copyright © 2023 OpenIM SDK. All rights reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package test

import (
	"context"
	"encoding/json"
	"testing"
	"time"

	"github.com/openimsdk/openim-sdk-core/v3/open_im_sdk"
	"github.com/openimsdk/openim-sdk-core/v3/pkg/cache"
	"github.com/openimsdk/openim-sdk-core/v3/pkg/ccontext"
	"github.com/openimsdk/openim-sdk-core/v3/pkg/sdk_params_callback"
	"github.com/openimsdk/openim-sdk-core/v3/sdk_struct"
	"github.com/openimsdk/protocol/conversation"
	"github.com/openimsdk/protocol/sdkws"
	"github.com/openimsdk/protocol/wrapperspb"
	"github.com/openimsdk/tools/log"
)

func Test_GetAllConversationList(t *testing.T) {
	conversations, err := open_im_sdk.IMUserContext.Conversation().GetAllConversationList(ctx)
	if err != nil {
		t.Fatal(err)
	}
	for _, conversation := range conversations {
		t.Log(conversation)
	}
	t.Log(len(conversations))
	time.Sleep(time.Second * 1000)
}

func Test_GetConversationListSplit(t *testing.T) {
	conversations, err := open_im_sdk.IMUserContext.Conversation().GetConversationListSplit(ctx, 0, 20)
	if err != nil {
		t.Fatal(err)
	}
	for _, conversation := range conversations {
		t.Log(conversation)
	}
}

func Test_HideConversation(t *testing.T) {
	err := open_im_sdk.IMUserContext.Conversation().HideConversation(ctx, "asdasd")
	if err != nil {
		t.Fatal(err)
	}
}

//func Test_GetConversationRecvMessageOpt(t *testing.T) {
//	opts, err := open_im_sdk.IMUserContext.Conversation().GetConversationRecvMessageOpt(ctx, []string{"asdasd"})
//	if err != nil {
//		t.Fatal(err)
//	}
//	for _, v := range opts {
//		t.Log(v.ConversationIDs, *v.Execute)
//	}
//}

func Test_GetGlobalRecvMessageOpt(t *testing.T) {
	opt, err := open_im_sdk.IMUserContext.Conversation().GetOneConversation(ctx, 2, "1772958501")
	if err != nil {
		t.Fatal(err)
	}
	t.Log(*opt)
}

func Test_GetGetMultipleConversation(t *testing.T) {
	conversations, err := open_im_sdk.IMUserContext.Conversation().GetMultipleConversation(ctx, []string{"asdasd"})
	if err != nil {
		t.Fatal(err)
	}
	for _, v := range conversations {
		t.Log(v)
	}
}

func Test_SetConversationDraft(t *testing.T) {
	err := open_im_sdk.IMUserContext.Conversation().SetConversationDraft(ctx, "group_17729585012", "draft")
	if err != nil {
		t.Fatal(err)
	}
}

func Test_SetConversation(t *testing.T) {
	err := open_im_sdk.IMUserContext.Conversation().SetConversation(ctx, "si_3632974546_5446165174", &conversation.ConversationReq{
		ConversationID: "si_3632974546_5446165174",
		IsMarked:       wrapperspb.Bool(true),
	})
	if err != nil {
		t.Fatal(err)
	}
}

func Test_GetTotalUnreadMsgCount(t *testing.T) {
	count, err := open_im_sdk.IMUserContext.Conversation().GetTotalUnreadMsgCount(ctx)
	if err != nil {
		t.Fatal(err)
	}
	t.Log(count)
}

func Test_SendMessage(t *testing.T) {
	ctx = context.WithValue(ctx, ccontext.CtxCallback, &TestSendMsg{})
	msg, _ := open_im_sdk.IMUserContext.Conversation().CreateTextMessage(ctx, "textMsg")
	offlinePush := &sdkws.OfflinePushInfo{
		Title:      "TestTitle",
		Desc:       "TestDesc",
		Ex:         "TestEx",
		SignalInfo: "TestSignalInfo",
	}
	_, err := open_im_sdk.IMUserContext.Conversation().SendMessage(ctx, msg, "2328144857", "", offlinePush, false)
	if err != nil {
		t.Fatal(err)
	}
}

func Test_SendMessageNotOss(t *testing.T) {
	ctx = context.WithValue(ctx, "callback", TestSendMsg{})
	msg, _ := open_im_sdk.IMUserContext.Conversation().CreateTextMessage(ctx, "textMsg")
	_, err := open_im_sdk.IMUserContext.Conversation().SendMessageNotOss(ctx, msg, "3411008330", "", nil, false)
	if err != nil {
		t.Fatal(err)
	}
}

func Test_FindMessageList(t *testing.T) {
	msgs, err := open_im_sdk.IMUserContext.Conversation().FindMessageList(ctx, []*sdk_params_callback.ConversationArgs{})
	if err != nil {
		t.Fatal(err)
	}
	t.Log(msgs.TotalCount)
	for _, v := range msgs.FindResultItems {
		t.Log(v)
	}
}

func Test_GetAdvancedHistoryMessageList(t *testing.T) {
	msgs, err := open_im_sdk.IMUserContext.Conversation().GetAdvancedHistoryMessageList(ctx, sdk_params_callback.GetAdvancedHistoryMessageListParams{
		ConversationID:   "si_3632974546_5446165174",
		StartClientMsgID: "",
		Count:            40,
		ViewType:         0,
	})
	if err != nil {
		t.Fatal(err)
	}
	dat, err := json.Marshal(msgs)
	if err != nil {
		t.Fatal(err)
	}
	t.Log(string(dat))
}

func Test_GetAdvancedHistoryMessageListReverse(t *testing.T) {
	msgs, err := open_im_sdk.IMUserContext.Conversation().GetAdvancedHistoryMessageListReverse(ctx, sdk_params_callback.GetAdvancedHistoryMessageListParams{
		ConversationID:   "si_3325086438_5054969402",
		StartClientMsgID: "91e40552a05a60494a56e86d36c497ce",
		Count:            20,
		ViewType:         cache.ViewHistory,
	})
	if err != nil {
		t.Fatal(err)
	}
	log.ZDebug(context.Background(), "GetAdvancedHistoryMessageListReverse Resp", "resp", msgs)
	for _, v := range msgs.MessageList {
		t.Log(v)
	}
}

func Test_InsertSingleMessageToLocalStorage(t *testing.T) {
	_, err := open_im_sdk.IMUserContext.Conversation().InsertSingleMessageToLocalStorage(ctx, &sdk_struct.MsgStruct{}, "3411008330", "")
	if err != nil {
		t.Fatal(err)
	}
}

func Test_InsertGroupMessageToLocalStorage(t *testing.T) {
	_, err := open_im_sdk.IMUserContext.Conversation().InsertGroupMessageToLocalStorage(ctx, &sdk_struct.MsgStruct{}, "group_17729585012", "")
	if err != nil {
		t.Fatal(err)
	}
}

func Test_SearchLocalMessages(t *testing.T) {
	req := &sdk_params_callback.SearchLocalMessagesParams{
		Count:            20,
		KeywordList:      []string{"1"},
		MessageTypeList:  []int{105},
		PageIndex:        1,
		SenderUserIDList: []string{},
	}
	msgs, err := open_im_sdk.IMUserContext.Conversation().SearchLocalMessages(ctx, req)
	if err != nil {
		t.Fatal(err)
	}
	for _, v := range msgs.SearchResultItems {
		t.Log(v)
	}
}

func Test_SetMessageLocalEx(t *testing.T) {
	err := open_im_sdk.IMUserContext.Conversation().SetMessageLocalEx(ctx, "si_2975755104_6386894923", "53ca4b3be29f7ea231a5e82e7af8a43f", "{key,value}")
	if err != nil {
		t.Fatal(err)
	}
}

func Test_DeleteAllMsgFromLocalAndSvr(t *testing.T) {
	err := open_im_sdk.IMUserContext.Conversation().DeleteAllMsgFromLocalAndServer(ctx)
	if err != nil {
		t.Fatal(err)
	}
}

func Test_DeleteAllMessageFromLocalStorage(t *testing.T) {
	err := open_im_sdk.IMUserContext.Conversation().DeleteAllMessageFromLocalStorage(ctx)
	if err != nil {
		t.Fatal(err)
	}
}

func Test_DeleteMessage(t *testing.T) {
	err := open_im_sdk.IMUserContext.Conversation().DeleteMessage(ctx, "si_1695766238_5099153716", "8b67803979bce9c6daf82fb64dbffc5f")
	if err != nil {
		t.Fatal(err)
	}
}

func Test_DeleteMessages(t *testing.T) {
	err := open_im_sdk.IMUserContext.Conversation().DeleteMessages(ctx, &sdk_params_callback.DeleteMessagesReq{
		ConversationID: "",
		ClientMsgIDs:   nil,
		IsSync:         false,
	})
	if err != nil {
		t.Fatal(err)
	}
	time.Sleep(time.Hour)
}

func Test_DeleteUserAllMessagesInConv(t *testing.T) {
	err := open_im_sdk.IMUserContext.Conversation().DeleteUserAllMessagesInConv(ctx, "sg_1322907227", "3996465806")

	if err != nil {
		t.Fatal(err)
	}
}

func Test_ClearConversationAndDeleteAllMsg(t *testing.T) {
	err := open_im_sdk.IMUserContext.Conversation().ClearConversationAndDeleteAllMsg(ctx, "si_3271407977_7152307910")
	if err != nil {
		t.Fatal(err)
	}
}

func Test_DeleteConversationAndDeleteAllMsg(t *testing.T) {
	err := open_im_sdk.IMUserContext.Conversation().DeleteConversationAndDeleteAllMsg(ctx, "si_3271407977_7152307910")
	if err != nil {
		t.Fatal(err)
	}
}

// func Test_RevokeMessage(t *testing.T) {
// 	err := open_im_sdk.IMUserContext.Conversation().RevokeMessage(ctx, &sdk_struct.MsgStruct{SessionType: 1, ContentType: 101,
// 		ClientMsgID: "380e2eb1709875340d769880982ebb21", Seq: 57, SendID: "9169012630", RecvID: "2456093263"})
// 	if err != nil {
// 		t.Fatal(err)
// 	}
// 	time.Sleep(time.Second * 10)
// }

func Test_MarkConversationMessageAsRead(t *testing.T) {
	err := open_im_sdk.IMUserContext.Conversation().MarkConversationMessageAsRead(ctx, "si_2688118337_7249315132")
	if err != nil {
		t.Fatal(err)
	}
}

func Test_MarkConversationMessageAsReadOnlyUnread(t *testing.T) {
	conversationID := "si_2688118337_7249315132"
	before, err := open_im_sdk.IMUserContext.Conversation().GetAdvancedHistoryMessageList(ctx, sdk_params_callback.GetAdvancedHistoryMessageListParams{
		ConversationID:   conversationID,
		StartClientMsgID: "",
		Count:            50,
		ViewType:         cache.ViewHistory,
	})
	if err != nil {
		t.Fatal(err)
	}
	if len(before.MessageList) == 0 {
		t.Skip("no messages in conversation")
	}
	unreadMsgIDs := make(map[string]struct{})
	for _, msg := range before.MessageList {
		if !msg.IsRead {
			unreadMsgIDs[msg.ClientMsgID] = struct{}{}
		}
	}
	if len(unreadMsgIDs) == 0 {
		t.Skip("no unread messages to mark")
	}

	err = open_im_sdk.IMUserContext.Conversation().MarkConversationMessageAsRead(ctx, conversationID)
	if err != nil {
		t.Fatal(err)
	}

	after, err := open_im_sdk.IMUserContext.Conversation().GetAdvancedHistoryMessageList(ctx, sdk_params_callback.GetAdvancedHistoryMessageListParams{
		ConversationID:   conversationID,
		StartClientMsgID: "",
		Count:            50,
		ViewType:         cache.ViewHistory,
	})
	if err != nil {
		t.Fatal(err)
	}
	for _, msg := range after.MessageList {
		if _, wasUnread := unreadMsgIDs[msg.ClientMsgID]; wasUnread && !msg.IsRead {
			t.Fatalf("message still unread after mark: %s", msg.ClientMsgID)
		}
	}
}

func Test_MarkAllConversationMessageAsRead(t *testing.T) {
	err := open_im_sdk.IMUserContext.Conversation().MarkAllConversationMessageAsRead(ctx)
	if err != nil {
		t.Fatal(err)
	}
}

func Test_MarkMsgsAsRead(t *testing.T) {
	err := open_im_sdk.IMUserContext.Conversation().MarkMessagesAsReadByMsgID(ctx, "si_2688118337_7249315132",
		[]string{"fb56ed151b675e0837ed3af79dbf66b1",
			"635715c539be2e7812a0fc802f0cdc54", "1aba3fae3dc3f61c17e8eb09519cf8e1"})
	if err != nil {
		t.Fatal(err)
	}
}

func Test_SendImgMsg(t *testing.T) {
	ctx = context.WithValue(ctx, "callback", TestSendMsg{})
	msg, err := open_im_sdk.IMUserContext.Conversation().CreateImageMessage(ctx, "C:\\Users\\Admin\\Desktop\\test.png")
	if err != nil {
		t.Fatal(err)
	}
	res, err := open_im_sdk.IMUserContext.Conversation().SendMessage(ctx, msg, "1919501984", "", nil, false)
	if err != nil {
		t.Fatal(err)
	}
	t.Logf("send smg => %+v\n", res)
}

func Test_SearchConversation(t *testing.T) {
	result, err := open_im_sdk.IMUserContext.Conversation().SearchConversation(ctx, "a")
	if err != nil {
		t.Fatal(err)
	}
	for _, v := range result {
		t.Log(v)
	}
}

func Test_SetLocalContent(t *testing.T) {
	conversationID := "si_3325086438_5054969402"
	res, err := open_im_sdk.IMUserContext.Conversation().GetAdvancedHistoryMessageList(ctx, sdk_params_callback.GetAdvancedHistoryMessageListParams{ConversationID: conversationID, Count: 1})
	if err != nil {
		t.Log(err)
		return
	}
	if len(res.MessageList) == 0 {
		t.Log("no message")
		return
	}
	if err := open_im_sdk.IMUserContext.Conversation().SetMessageLocalContent(ctx, conversationID, res.MessageList[0]); err != nil {
		t.Log(err)
		return
	}

}
