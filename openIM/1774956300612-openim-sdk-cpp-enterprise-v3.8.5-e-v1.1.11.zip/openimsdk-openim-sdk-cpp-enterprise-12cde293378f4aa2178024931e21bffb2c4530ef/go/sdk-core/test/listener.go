// Copyright © 2023 OpenIM SDK. All rights reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package test

import (
	"context"
	"fmt"

	"github.com/openimsdk/tools/log"
)

type OnConnListener struct{}

func (c *OnConnListener) OnUserTokenInvalid(errMsg string) {}

func (c *OnConnListener) OnConnecting() {
	// fmt.Println("OnConnecting")
}

func (c *OnConnListener) OnConnectSuccess() {
	// fmt.Println("OnConnectSuccess")
}

func (c *OnConnListener) OnConnectFailed(errCode int32, errMsg string) {
	// fmt.Println("OnConnectFailed")
}

func (c *OnConnListener) OnKickedOffline(msg string) {
	log.ZInfo(ctx, "OnKickedOffline", "data", msg)
}

func (c *OnConnListener) OnUserTokenExpired() {
	// fmt.Println("OnUserTokenExpired")
}

type onConversationListener struct {
	ctx                context.Context
	ch                 chan error
	groupAddedCh       chan string
	groupUpdatedCh     chan string
	groupDeletedCh     chan string
	groupMemberAddedCh chan string
	groupMemberDelCh   chan string
}

func (o *onConversationListener) OnSyncServerStart(reinstalled bool) {
	log.ZInfo(o.ctx, "OnSyncServerStart")
}

func (o *onConversationListener) OnSyncServerFinish(reinstalled bool) {
	log.ZInfo(o.ctx, "OnSyncServerFinish")
	o.ch <- nil
}

func (o *onConversationListener) OnSyncServerFailed(reinstalled bool) {
	log.ZInfo(o.ctx, "OnSyncServerFailed")
	o.ch <- fmt.Errorf("OnSyncServerFailed")
}

func (o *onConversationListener) OnSyncServerProgress(progress int) {
	log.ZInfo(o.ctx, "OnSyncServerProgress", "progress", progress)
}

func (o *onConversationListener) OnNewConversation(conversationList string) {
	log.ZInfo(o.ctx, "OnNewConversation", "conversationList", conversationList)
}

func (o *onConversationListener) OnConversationChanged(conversationList string) {
	log.ZInfo(o.ctx, "OnConversationChanged", "####### conversationList", conversationList)
}

func (o *onConversationListener) OnConversationGroupChanged(conversationList string) {
	log.ZInfo(o.ctx, "OnConversationGroupChanged", "####### conversationList", conversationList)
}

func (o *onConversationListener) OnConversationGroupAdded(groupInfo string) {
	log.ZInfo(o.ctx, "OnConversationGroupAdded", "groupInfo", groupInfo)
}

func (o *onConversationListener) OnConversationGroupDeleted(groupInfo string) {
	log.ZInfo(o.ctx, "OnConversationGroupDeleted", "groupInfo", groupInfo)
}

func (o *onConversationListener) OnConversationGroupMemberAdded(change string) {
	log.ZInfo(o.ctx, "OnConversationGroupMemberAdded", "change", change)
}

func (o *onConversationListener) OnConversationGroupMemberDeleted(change string) {
	log.ZInfo(o.ctx, "OnConversationGroupMemberDeleted", "change", change)
}

func (o *onConversationListener) OnTotalUnreadMessageCountChanged(totalUnreadCount int32) {
	log.ZInfo(o.ctx, "OnTotalUnreadMessageCountChanged", "totalUnreadCount", totalUnreadCount)
}

func (o *onConversationListener) OnConversationUserInputStatusChanged(change string) {
	log.ZInfo(o.ctx, "OnConversationUserInputStatusChanged", "change", change)
}

type onGroupListener struct {
	ctx context.Context
}

func (o *onGroupListener) OnGroupDismissed(groupInfo string) {
	log.ZInfo(o.ctx, "OnGroupDismissed", "groupInfo", groupInfo)
}

func (o *onGroupListener) OnJoinedGroupAdded(groupInfo string) {
	log.ZInfo(o.ctx, "OnJoinedGroupAdded", "groupInfo", groupInfo)
}

func (o *onGroupListener) OnJoinedGroupDeleted(groupInfo string) {
	log.ZInfo(o.ctx, "OnJoinedGroupDeleted", "groupInfo", groupInfo)
}

func (o *onGroupListener) OnGroupMemberAdded(groupMemberInfo string) {
	log.ZInfo(o.ctx, "OnGroupMemberAdded", "groupMemberInfo", groupMemberInfo)
}

func (o *onGroupListener) OnGroupMemberDeleted(groupMemberInfo string) {
	log.ZInfo(o.ctx, "OnGroupMemberDeleted", "groupMemberInfo", groupMemberInfo)
}

func (o *onGroupListener) OnGroupApplicationAdded(groupApplication string) {
	log.ZInfo(o.ctx, "OnGroupApplicationAdded", "groupApplication", groupApplication)
}

func (o *onGroupListener) OnGroupApplicationDeleted(groupApplication string) {
	log.ZInfo(o.ctx, "OnGroupApplicationDeleted", "groupApplication", groupApplication)
}

func (o *onGroupListener) OnGroupInfoChanged(groupInfo string) {
	log.ZInfo(o.ctx, "OnGroupInfoChanged", "groupInfo", groupInfo)
}

func (o *onGroupListener) OnGroupMemberInfoChanged(groupMemberInfo string) {
	log.ZInfo(o.ctx, "OnGroupMemberInfoChanged", "groupMemberInfo", groupMemberInfo)
}

func (o *onGroupListener) OnGroupApplicationAccepted(groupApplication string) {
	log.ZInfo(o.ctx, "OnGroupApplicationAccepted", "groupApplication", groupApplication)
}

func (o *onGroupListener) OnGroupApplicationRejected(groupApplication string) {
	log.ZInfo(o.ctx, "OnGroupApplicationRejected", "groupApplication", groupApplication)
}

type onAdvancedMsgListener struct {
	ctx context.Context
}

func (o *onAdvancedMsgListener) OnMessageModified(message string) {
	log.ZInfo(o.ctx, "OnMessageModified", "message", message)
}

func (o *onAdvancedMsgListener) OnRecvOnlineOnlyMessage(message string) {
	log.ZDebug(o.ctx, "OnRecvOnlineOnlyMessage", "message", message)
}

func (o *onAdvancedMsgListener) OnRecvOfflineNewMessage(message string) {
	log.ZDebug(o.ctx, "OnRecvOfflineNewMessage", "message", message)
}

func (o *onAdvancedMsgListener) OnMsgDeleted(message string) {
	log.ZInfo(o.ctx, "OnMsgDeleted", "message", message)
}

func (o *onAdvancedMsgListener) OnDeleteUserAllMsgsInConv(message string) {
	log.ZInfo(o.ctx, "OnDeleteUserAllMsgsInConv", "message", message)
}

func (o *onAdvancedMsgListener) OnRecvOfflineNewMessages(messageList string) {
	log.ZInfo(o.ctx, "OnRecvOfflineNewMessages", "messageList", messageList)
}

func (o *onAdvancedMsgListener) OnRecvNewMessage(message string) {
	log.ZInfo(o.ctx, "OnRecvNewMessage", "message", message)
}

func (o *onAdvancedMsgListener) OnRecvC2CReadReceipt(msgReceiptList string) {
	log.ZInfo(o.ctx, "OnRecvC2CReadReceipt", "msgReceiptList", msgReceiptList)
}

func (o *onAdvancedMsgListener) OnRecvGroupReadReceipt(groupMsgReceiptList string) {
	log.ZInfo(o.ctx, "OnRecvGroupReadReceipt", "groupMsgReceiptList", groupMsgReceiptList)
}

func (o *onAdvancedMsgListener) OnRecvMessageRevoked(msgID string) {
	log.ZInfo(o.ctx, "OnRecvMessageRevoked", "msgID", msgID)
}

func (o *onAdvancedMsgListener) OnNewRecvMessageRevoked(messageRevoked string) {
	log.ZInfo(o.ctx, "OnNewRecvMessageRevoked", "messageRevoked", messageRevoked)
}

func (o *onAdvancedMsgListener) OnRecvMessageExtensionsChanged(msgID string, reactionExtensionList string) {
	log.ZInfo(o.ctx, "OnRecvMessageExtensionsChanged", "msgID", msgID, "reactionExtensionList", reactionExtensionList)
}

func (o *onAdvancedMsgListener) OnRecvMessageExtensionsDeleted(msgID string, reactionExtensionKeyList string) {
	log.ZInfo(o.ctx, "OnRecvMessageExtensionsDeleted", "msgID", msgID, "reactionExtensionKeyList", reactionExtensionKeyList)
}

func (o *onAdvancedMsgListener) OnRecvMessageExtensionsAdded(msgID string, reactionExtensionList string) {
	log.ZInfo(o.ctx, "OnRecvMessageExtensionsAdded", "msgID", msgID, "reactionExtensionList", reactionExtensionList)
}

func (o *onAdvancedMsgListener) OnChangedPinnedMsg(message string) {
	log.ZInfo(o.ctx, "OnChangedPinnedMsg", "message", message)
}

type onFriendshipListener struct {
	ctx context.Context
}

func (o *onFriendshipListener) OnFriendApplicationAdded(friendApplication string) {
	log.ZDebug(context.Background(), "OnFriendApplicationAdded", "friendApplication", friendApplication)
}

func (o *onFriendshipListener) OnFriendApplicationDeleted(friendApplication string) {
	log.ZDebug(context.Background(), "OnFriendApplicationDeleted", "friendApplication", friendApplication)
}

func (o *onFriendshipListener) OnFriendApplicationAccepted(friendApplication string) {
	log.ZDebug(context.Background(), "OnFriendApplicationAccepted", "friendApplication", friendApplication)
}

func (o *onFriendshipListener) OnFriendApplicationRejected(friendApplication string) {
	log.ZDebug(context.Background(), "OnFriendApplicationRejected", "friendApplication", friendApplication)
}

func (o *onFriendshipListener) OnFriendAdded(friendInfo string) {
	log.ZDebug(context.Background(), "OnFriendAdded", "friendInfo", friendInfo)
}

func (o *onFriendshipListener) OnFriendDeleted(friendInfo string) {
	log.ZDebug(context.Background(), "OnFriendDeleted", "friendInfo", friendInfo)
}

func (o *onFriendshipListener) OnFriendInfoChanged(friendInfo string) {
	log.ZDebug(context.Background(), "OnFriendInfoChanged", "friendInfo", friendInfo)
}

func (o *onFriendshipListener) OnBlackAdded(blackInfo string) {
	log.ZDebug(context.Background(), "OnBlackAdded", "blackInfo", blackInfo)
}

func (o *onFriendshipListener) OnBlackDeleted(blackInfo string) {
	log.ZDebug(context.Background(), "OnBlackDeleted", "blackInfo", blackInfo)
}

type OnSignalingListener struct{}

func (o *OnSignalingListener) OnReceiveNewInvitation(receiveNewInvitationCallback string) {
	log.ZInfo(context.Background(), "OnReceiveNewInvitation", "receiveNewInvitationCallback", receiveNewInvitationCallback)
}

func (o *OnSignalingListener) OnInviteeAccepted(inviteeAcceptedCallback string) {
	log.ZInfo(context.Background(), "OnInviteeAccepted", "inviteeAcceptedCallback", inviteeAcceptedCallback)
}

func (o *OnSignalingListener) OnInviteeAcceptedByOtherDevice(inviteeAcceptedCallback string) {
	log.ZInfo(context.Background(), "OnInviteeAcceptedByOtherDevice", "inviteeAcceptedCallback", inviteeAcceptedCallback)
}

func (o *OnSignalingListener) OnInviteeRejected(inviteeRejectedCallback string) {
	log.ZInfo(context.Background(), "OnInviteeRejected", "inviteeRejectedCallback", inviteeRejectedCallback)
}

func (o *OnSignalingListener) OnInviteeRejectedByOtherDevice(inviteeRejectedCallback string) {
	log.ZInfo(context.Background(), "OnInviteeRejectedByOtherDevice", "inviteeRejectedCallback", inviteeRejectedCallback)
}

func (o *OnSignalingListener) OnInvitationCancelled(invitationCancelledCallback string) {
	log.ZInfo(context.Background(), "OnInvitationCancelled", "invitationCancelledCallback", invitationCancelledCallback)
}

func (o *OnSignalingListener) OnInvitationTimeout(invitationTimeoutCallback string) {
	log.ZInfo(context.Background(), "OnInvitationTimeout", "invitationTimeoutCallback", invitationTimeoutCallback)
}

func (o *OnSignalingListener) OnHangUp(hangUpCallback string) {
	log.ZInfo(context.Background(), "OnHangUp", "hangUpCallback", hangUpCallback)
}

func (o *OnSignalingListener) OnRoomParticipantConnected(onRoomParticipantConnectedCallback string) {
	log.ZInfo(context.Background(), "OnRoomParticipantConnected", "onRoomParticipantConnectedCallback", onRoomParticipantConnectedCallback)
}

func (o *OnSignalingListener) OnRoomParticipantDisconnected(onRoomParticipantDisconnectedCallback string) {
	log.ZInfo(context.Background(), "OnRoomParticipantDisconnected", "onRoomParticipantDisconnectedCallback", onRoomParticipantDisconnectedCallback)
}

func (o *OnSignalingListener) OnStreamChange(OnStreamChangeCallback string) {
	log.ZInfo(context.Background(), "OnStreamChange", "OnStreamChangeCallback", OnStreamChangeCallback)
}

func (o *OnSignalingListener) OnReceiveCustomSignal(CustomSignalCallback string) {
	log.ZInfo(context.Background(), "OnReceiveCustomSignal", "CustomSignalCallback", CustomSignalCallback)
}

type onUserListener struct {
	ctx context.Context
}

func (o *onUserListener) OnSelfInfoUpdated(userInfo string) {
	log.ZDebug(context.Background(), "OnSelfInfoUpdated", "userInfo", userInfo)
}

func (o *onUserListener) OnUserStatusChanged(statusMap string) {
	log.ZDebug(context.Background(), "OnUserStatusChanged", "OnUserStatusChanged", statusMap)
}

type onMessageKvInfoListener struct {
	ctx context.Context
}

func (o *onMessageKvInfoListener) OnMessageKvInfoChanged(messageChangedList string) {
	log.ZDebug(o.ctx, "OnMessageKvInfoChanged", "messageChangedList", messageChangedList)
}

type onCustomBusinessListener struct {
	ctx context.Context
}

func (o *onCustomBusinessListener) OnRecvCustomBusinessMessage(businessMessage string) {
	log.ZDebug(o.ctx, "OnRecvCustomBusinessMessage", "businessMessage", businessMessage)
}
