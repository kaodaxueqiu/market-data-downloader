// Copyright © 2023 OpenIM SDK. All rights reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

//go:build !js
// +build !js

package db

import (
	"context"
	"errors"
	"fmt"
	"strings"
	"time"

	"gorm.io/gorm"
	"gorm.io/gorm/clause"

	"github.com/openimsdk/openim-sdk-core/v3/pkg/constant"
	"github.com/openimsdk/openim-sdk-core/v3/pkg/db/model_struct"
	"github.com/openimsdk/openim-sdk-core/v3/pkg/utils"
	"github.com/openimsdk/openim-sdk-core/v3/sdk_struct"

	"github.com/openimsdk/tools/errs"
	"github.com/openimsdk/tools/log"
)

func (d *DataBase) initChatLog(ctx context.Context, conversationID string) error {
	d.mRWMutex.Lock()
	defer d.mRWMutex.Unlock()
	tableName := utils.GetTableName(conversationID)
	if !d.tableChecker.HasTable(tableName) {
		createTableSQL := fmt.Sprintf(`
            CREATE TABLE "%s" (
                client_msg_id CHAR(64),
                server_msg_id CHAR(64),
                send_id CHAR(64),
                recv_id CHAR(64),
                sender_platform_id INTEGER,
                sender_nick_name VARCHAR(255),
                sender_face_url VARCHAR(255),
                session_type INTEGER,
                msg_from INTEGER,
                content_type INTEGER,
                content VARCHAR(1000),
                is_read NUMERIC,
                status INTEGER,
                seq INTEGER DEFAULT 0,
                send_time INTEGER,
                create_time INTEGER,
                attached_info VARCHAR(1024),
                ex VARCHAR(1024),
                local_ex VARCHAR(1024),
                is_react NUMERIC,
                is_external_extensions NUMERIC,
                msg_first_modify_time INTEGER,
                dst_user_ids  text,
                PRIMARY KEY (client_msg_id)
            );`, tableName)

		if result := d.conn.Exec(createTableSQL); result.Error != nil {
			return errs.WrapMsg(result.Error, "Create table failed", "table", tableName)
		}
		result := d.conn.Exec(fmt.Sprintf("CREATE INDEX `%s` ON `%s` (seq)", "index_seq_"+conversationID, tableName))
		if result.Error != nil {
			return errs.WrapMsg(result.Error, "Create index_seq failed", "table", tableName, "index", "index_seq_"+conversationID)
		}
		result = d.conn.Exec(fmt.Sprintf("CREATE INDEX `%s` ON `%s` (send_time)", "index_send_time_"+conversationID, tableName))
		if result.Error != nil {
			return errs.WrapMsg(result.Error, "Create index_send_time failed", "table", tableName, "index", "index_send_time_"+conversationID)
		}
		d.tableChecker.UpdateTable(tableName)
	}
	return nil
}

func (d *DataBase) checkTable(ctx context.Context, tableName string) bool {
	return d.conn.Migrator().HasTable(tableName)
}

func (d *DataBase) UpdateMessage(ctx context.Context, conversationID string, c *model_struct.LocalChatLog) error {
	d.mRWMutex.Lock()
	defer d.mRWMutex.Unlock()
	t := d.conn.WithContext(ctx).Table(utils.GetTableName(conversationID)).Updates(c)
	if t.RowsAffected == 0 {
		return errs.WrapMsg(errors.New("RowsAffected == 0"), "no update ")
	}
	return errs.WrapMsg(t.Error, "UpdateMessage failed")
}

func (d *DataBase) UpdateMessageBySeq(ctx context.Context, conversationID string, c *model_struct.LocalChatLog) error {
	d.mRWMutex.Lock()
	defer d.mRWMutex.Unlock()
	return errs.WrapMsg(d.conn.WithContext(ctx).Table(utils.GetTableName(conversationID)).Where("seq=?", c.Seq).Updates(c).Error, "UpdateMessage failed")
}

func (d *DataBase) BatchInsertMessageList(ctx context.Context, conversationID string, MessageList []*model_struct.LocalChatLog) error {
	err := d.initChatLog(ctx, conversationID)
	if err != nil {
		log.ZWarn(ctx, "initChatLog err", err)
		return err
	}

	if MessageList == nil {
		return nil
	}
	d.mRWMutex.Lock()
	defer d.mRWMutex.Unlock()
	// Ignore duplicates on primary key (client_msg_id) to avoid failing the whole batch.
	return errs.WrapMsg(
		d.conn.WithContext(ctx).
			Table(utils.GetTableName(conversationID)).
			Clauses(clause.OnConflict{DoNothing: true}).
			Create(MessageList).Error,
		"BatchInsertMessageList failed",
	)
}

// BatchInsertMessageMap inserts messages across multiple conversation tables in a single transaction.
// This reduces commit/fsync overhead when a batch contains many conversations (many tables).
func (d *DataBase) BatchInsertMessageMap(ctx context.Context, insertMsg map[string][]*model_struct.LocalChatLog) error {
	if insertMsg == nil {
		return nil
	}

	start := time.Now()
	totalConversations := len(insertMsg)
	totalMessages := 0
	for _, ms := range insertMsg {
		totalMessages += len(ms)
	}

	// Ensure tables exist before starting the transaction to avoid DDL in the write path.
	for conversationID := range insertMsg {
		if err := d.initChatLog(ctx, conversationID); err != nil {
			log.ZWarn(ctx, "initChatLog err", err, "conversationID", conversationID)
			return err
		}
	}

	d.mRWMutex.Lock()
	defer d.mRWMutex.Unlock()

	var maxSingleInsert time.Duration
	var maxSingleInsertConversationID string

	txErr := d.conn.WithContext(ctx).Transaction(func(tx *gorm.DB) error {
		tx = tx.Session(&gorm.Session{SkipDefaultTransaction: true})
		for conversationID, messages := range insertMsg {
			if len(messages) == 0 {
				continue
			}
			t0 := time.Now()
			if err := tx.WithContext(ctx).
				Table(utils.GetTableName(conversationID)).
				Clauses(clause.OnConflict{DoNothing: true}).
				Create(messages).Error; err != nil {
				return err
			}
			if dur := time.Since(t0); dur > maxSingleInsert {
				maxSingleInsert = dur
				maxSingleInsertConversationID = conversationID
			}
		}
		return nil
	})
	if txErr == nil {
		if dur := time.Since(start); dur > 50*time.Millisecond {
			log.ZDebug(
				ctx,
				"BatchInsertMessageMap done",
				"duration", dur.String(),
				"conversations", totalConversations,
				"messages", totalMessages,
				"slowestTable", maxSingleInsertConversationID,
				"slowestTableDuration", maxSingleInsert.String(),
			)
		}
	}
	return errs.WrapMsg(txErr, "BatchInsertMessageMap failed")
}

func (d *DataBase) InsertMessage(ctx context.Context, conversationID string, Message *model_struct.LocalChatLog) error {
	d.mRWMutex.Lock()
	defer d.mRWMutex.Unlock()
	return errs.WrapMsg(d.conn.WithContext(ctx).Table(utils.GetTableName(conversationID)).Create(Message).Error, "InsertMessage failed")
}
func (d *DataBase) GetMessage(ctx context.Context, conversationID string, clientMsgID string) (*model_struct.LocalChatLog, error) {
	err := d.initChatLog(ctx, conversationID)
	if err != nil {
		log.ZWarn(ctx, "initChatLog err", err)
		return nil, err
	}
	d.mRWMutex.RLock()
	defer d.mRWMutex.RUnlock()
	var c model_struct.LocalChatLog
	return &c, errs.WrapMsg(d.conn.WithContext(ctx).Table(utils.GetTableName(conversationID)).Where("client_msg_id = ?",
		clientMsgID).Take(&c).Error, "GetMessage failed")
}

func (d *DataBase) GetMessageByUserID(ctx context.Context, conversationID string, userID string) ([]*model_struct.LocalChatLog, error) {
	err := d.initChatLog(ctx, conversationID)
	if err != nil {
		log.ZWarn(ctx, "initChatLog err", err)
		return nil, err
	}
	d.mRWMutex.RLock()
	defer d.mRWMutex.RUnlock()
	var result []*model_struct.LocalChatLog

	return result, errs.WrapMsg(d.conn.WithContext(ctx).Table(utils.GetTableName(conversationID)).Where("send_id = ?",
		userID).Find(&result).Error, "GetMessage failed")
}

func (d *DataBase) GetMessageBySeq(ctx context.Context, conversationID string, seq int64) (*model_struct.LocalChatLog, error) {
	err := d.initChatLog(ctx, conversationID)
	if err != nil {
		log.ZWarn(ctx, "initChatLog err", err)
		return nil, err
	}
	d.mRWMutex.RLock()
	defer d.mRWMutex.RUnlock()
	var c model_struct.LocalChatLog
	dbErr := d.conn.WithContext(ctx).Table(utils.GetTableName(conversationID)).Where("seq = ?", seq).Take(&c).Error
	if dbErr != nil {
		if errors.Is(dbErr, gorm.ErrRecordNotFound) {
			return nil, errs.ErrRecordNotFound.Wrap()
		}
		return nil, errs.WrapMsg(dbErr, "GetMessage failed")
	}
	return &c, nil
}

func (d *DataBase) UpdateMessageTimeAndStatus(ctx context.Context, conversationID, clientMsgID string, serverMsgID string, sendTime int64, status int32) error {
	d.mRWMutex.Lock()
	defer d.mRWMutex.Unlock()
	return errs.WrapMsg(d.conn.WithContext(ctx).Table(utils.GetTableName(conversationID)).Model(model_struct.LocalChatLog{}).Where("client_msg_id=? And seq=?", clientMsgID, 0).
		Updates(model_struct.LocalChatLog{Status: status, SendTime: sendTime, ServerMsgID: serverMsgID}).Error, "UpdateMessageStatusBySourceID failed")
}

func (d *DataBase) GetMessageList(ctx context.Context, conversationID string, count int, startTime, startSeq int64, startClientMsgID string, isReverse bool) (result []*model_struct.LocalChatLog, err error) {
	if err = d.initChatLog(ctx, conversationID); err != nil {
		log.ZWarn(ctx, "initChatLog err", err)
		return nil, err
	}
	d.mRWMutex.RLock()
	defer d.mRWMutex.RUnlock()
	var condition, timeOrder, timeSymbol string
	if isReverse {
		timeOrder = "send_time ASC,seq ASC"
		timeSymbol = ">"
	} else {
		timeOrder = "send_time DESC,seq DESC"
		timeSymbol = "<"
	}
	if startTime > 0 {
		condition = "send_time " + timeSymbol + " ? " +
			"OR (send_time = ? AND (seq " + timeSymbol + " ? OR (seq = 0 AND client_msg_id != ?)))"
		err = errs.WrapMsg(d.conn.WithContext(ctx).Table(utils.GetTableName(conversationID)).
			Where(condition, startTime, startTime, startSeq, startClientMsgID).
			Order(timeOrder).Offset(0).Limit(count).Find(&result).Error, "GetMessageList failed")
		if err != nil {
			return nil, err
		}
	} else {
		err = errs.WrapMsg(d.conn.WithContext(ctx).Table(utils.GetTableName(conversationID)).Order(timeOrder).
			Offset(0).Limit(count).Find(&result).Error, "GetMessageList failed")
		if err != nil {
			return nil, err
		}
	}
	return result, err
}

func (d *DataBase) DeleteConversationAllMessages(ctx context.Context, conversationID string) error {
	d.mRWMutex.Lock()
	defer d.mRWMutex.Unlock()
	return errs.WrapMsg(d.conn.WithContext(ctx).Table(utils.GetTableName(conversationID)).Where("1 = 1").Delete(model_struct.LocalChatLog{}).Error, "DeleteConversationAllMessages failed")
}

func (d *DataBase) MarkDeleteConversationAllMessages(ctx context.Context, conversationID string) error {
	d.mRWMutex.Lock()
	defer d.mRWMutex.Unlock()
	return errs.WrapMsg(d.conn.WithContext(ctx).Table(utils.GetTableName(conversationID)).Where("1 = 1").Updates(model_struct.LocalChatLog{Status: constant.MsgStatusHasDeleted}).Error, "DeleteConversationAllMessages failed")
}

func (d *DataBase) DeleteConversationMsgs(ctx context.Context, conversationID string, msgIDs []string) error {
	d.mRWMutex.Lock()
	defer d.mRWMutex.Unlock()
	return errs.WrapMsg(d.conn.WithContext(ctx).Table(utils.GetTableName(conversationID)).Where("client_msg_id IN ?", msgIDs).Delete(model_struct.LocalChatLog{}).Error, "DeleteConversationMsgs failed")
}

func (d *DataBase) DeleteConversationMsgsBySeqs(ctx context.Context, conversationID string, seqs []int64) error {
	d.mRWMutex.Lock()
	defer d.mRWMutex.Unlock()
	return errs.WrapMsg(d.conn.WithContext(ctx).Table(utils.GetTableName(conversationID)).Where("seq IN ?", seqs).Delete(model_struct.LocalChatLog{}).Error, "DeleteConversationMsgs failed")
}

func (d *DataBase) SearchMessageByContentType(ctx context.Context, contentType []int, senderUserIDList []string, conversationID string, startTime, endTime int64, offset, count int) (result []*model_struct.LocalChatLog, err error) {
	d.mRWMutex.RLock()
	defer d.mRWMutex.RUnlock()

	db := d.conn.WithContext(ctx).
		Table(utils.GetTableName(conversationID)).
		Where("send_time BETWEEN ? AND ?", startTime, endTime).
		Where("status <= ?", constant.MsgStatusSendFailed).
		Where("content_type IN ?", contentType)

	if len(senderUserIDList) > 0 {
		db = db.Where("send_id IN ?", senderUserIDList)
	}

	err = errs.WrapMsg(
		db.Order("send_time DESC").
			Offset(offset).
			Limit(count).
			Find(&result).Error,
		"SearchMessage failed",
	)
	return result, err
}

func (d *DataBase) SearchMessageByKeyword(ctx context.Context, contentType []int, senderUserIDList []string,
	keywordList []string, keywordListMatchType int, conversationID string, startTime, endTime int64, offset, count int) (result []*model_struct.LocalChatLog, err error) {
	d.mRWMutex.RLock()
	defer d.mRWMutex.RUnlock()

	query := d.conn.WithContext(ctx).Table(utils.GetTableName(conversationID)).
		Where("send_time BETWEEN ? AND ?", startTime, endTime).
		Where("status <= ?", constant.MsgStatusSendFailed).
		Where("content_type IN ?", contentType)

	if len(keywordList) > 0 {
		if keywordListMatchType == constant.KeywordMatchOr {
			orConditions := make([]string, len(keywordList))
			args := make([]any, len(keywordList))
			for i, keyword := range keywordList {
				orConditions[i] = "content LIKE ?"
				args[i] = "%" + keyword + "%"
			}
			query = query.Where("("+strings.Join(orConditions, " OR ")+")", args...)

		} else {
			// Use AND logic for other keywordListMatchType
			for _, keyword := range keywordList {
				query = query.Where("content LIKE ?", "%"+keyword+"%")
			}
		}
	}

	// senderUserIDList
	if len(senderUserIDList) > 0 {
		query = query.Where("send_id IN ?", senderUserIDList)
	}
	err = errs.WrapMsg(query.Order("send_time DESC").
		Offset(offset).
		Limit(count).
		Find(&result).Error, "SearchMessage failed")

	return result, err
}

// SearchMessageByContentTypeAndKeyword searches for messages in the database that match specified content types and keywords within a given time range.
func (d *DataBase) SearchMessageByContentTypeAndKeyword(ctx context.Context, contentType []int, conversationID string, senderUserIDList []string, keywordList []string, keywordListMatchType int, startTime, endTime int64) (result []*model_struct.LocalChatLog, err error) {
	d.mRWMutex.RLock()
	defer d.mRWMutex.RUnlock()

	query := d.conn.WithContext(ctx).Table(utils.GetTableName(conversationID)).
		Where("send_time BETWEEN ? AND ?", startTime, endTime).
		Where("status <= ?", constant.MsgStatusSendFailed).
		Where("content_type IN ?", contentType)

	if len(keywordList) > 0 {
		if keywordListMatchType == constant.KeywordMatchOr {
			orConditions := make([]string, len(keywordList))
			args := make([]any, len(keywordList))
			for i, keyword := range keywordList {
				orConditions[i] = "content LIKE ?"
				args[i] = "%" + keyword + "%"
			}
			query = query.Where("("+strings.Join(orConditions, " OR ")+")", args...)

		} else {
			// Use AND logic for other keywordListMatchType
			for _, keyword := range keywordList {
				query = query.Where("content LIKE ?", "%"+keyword+"%")
			}
		}
	}
	// senderUserIDList
	if len(senderUserIDList) > 0 {
		query = query.Where("send_id IN ?", senderUserIDList)
	}

	err = errs.WrapMsg(query.Order("send_time DESC").
		Find(&result).Error, "SearchMessage failed")

	return result, err
}

func (d *DataBase) UpdateMsgSenderFaceURLAndSenderNickname(ctx context.Context, conversationID, sendID, faceURL, nickname string) error {
	d.mRWMutex.Lock()
	defer d.mRWMutex.Unlock()
	return errs.WrapMsg(d.conn.WithContext(ctx).Table(utils.GetTableName(conversationID)).Model(model_struct.LocalChatLog{}).Where(
		"send_id = ?", sendID).Updates(
		map[string]interface{}{"sender_face_url": faceURL, "sender_nick_name": nickname}).Error, utils.GetSelfFuncName()+" failed")
}

func (d *DataBase) UpdateColumnsMessage(ctx context.Context, conversationID, ClientMsgID string, args map[string]interface{}) error {
	d.mRWMutex.Lock()
	defer d.mRWMutex.Unlock()
	c := model_struct.LocalChatLog{ClientMsgID: ClientMsgID}
	t := d.conn.WithContext(ctx).Table(utils.GetConversationTableName(conversationID)).Model(&c).Updates(args)
	if t.RowsAffected == 0 {
		return errs.WrapMsg(errors.New("RowsAffected == 0"), "no update")
	}
	return errs.WrapMsg(t.Error, "UpdateColumnsConversation failed")
}
func (d *DataBase) SearchAllMessageByContentType(ctx context.Context, conversationID string, contentType int) (result []*model_struct.LocalChatLog, err error) {
	d.mRWMutex.RLock()
	defer d.mRWMutex.RUnlock()
	err = d.conn.WithContext(ctx).Table(utils.GetTableName(conversationID)).Model(&model_struct.LocalChatLog{}).Where("content_type = ?", contentType).Find(&result).Error
	return result, err
}
func (d *DataBase) GetUnreadMessage(ctx context.Context, conversationID string) (msgs []*model_struct.LocalChatLog, err error) {
	d.mRWMutex.RLock()
	defer d.mRWMutex.RUnlock()
	err = errs.WrapMsg(d.conn.WithContext(ctx).Table(utils.GetConversationTableName(conversationID)).Debug().Where("send_id != ? AND is_read = ?", d.loginUserID, constant.NotRead).Find(&msgs).Error, "GetMessageList failed")
	return msgs, err
}

func (d *DataBase) MarkConversationMessageAsReadBySeqs(ctx context.Context, conversationID string, seqs []int64) (rowsAffected int64, err error) {
	d.mRWMutex.Lock()
	defer d.mRWMutex.Unlock()
	t := d.conn.WithContext(ctx).Table(utils.GetConversationTableName(conversationID)).Where("seq in ? AND send_id != ?", seqs, d.loginUserID).Update("is_read", constant.HasRead)
	if t.RowsAffected == 0 {
		return 0, errs.WrapMsg(errors.New("RowsAffected == 0"), "no update")
	}
	return t.RowsAffected, errs.WrapMsg(t.Error, "UpdateMessageStatusBySourceID failed")
}

func (d *DataBase) DeleteMessagesByClientMsgIDs(ctx context.Context, conversationID string, msgIDs []string) (rowsAffected int64, err error) {
	d.mRWMutex.Lock()
	defer d.mRWMutex.Unlock()

	t := d.conn.WithContext(ctx).Table(utils.GetConversationTableName(conversationID)).
		Where("client_msg_id in ? ", msgIDs).Update("status", constant.MsgStatusHasDeleted)

	if t.RowsAffected == 0 {
		return 0, errs.WrapMsg(errors.New("RowsAffected == 0"), "no messages updated")
	}

	return t.RowsAffected, errs.WrapMsg(t.Error, "Failed to update message status")
}

func (d *DataBase) MarkConversationMessageAsReadDB(ctx context.Context, conversationID string, msgIDs []string) (rowsAffected int64, err error) {
	d.mRWMutex.Lock()
	defer d.mRWMutex.Unlock()
	var msgs []*model_struct.LocalChatLog
	if err := d.conn.WithContext(ctx).Table(utils.GetConversationTableName(conversationID)).Where("client_msg_id in ? AND send_id != ?", msgIDs, d.loginUserID).Find(&msgs).Error; err != nil {
		return 0, errs.WrapMsg(err, "MarkConversationMessageAsReadDB failed")
	}
	for _, msg := range msgs {
		var attachedInfo sdk_struct.AttachedInfoElem
		utils.JsonStringToStruct(msg.AttachedInfo, &attachedInfo)
		attachedInfo.HasReadTime = utils.GetCurrentTimestampByMill()
		msg.IsRead = true
		msg.AttachedInfo = utils.StructToJsonString(attachedInfo)
		if err := d.conn.WithContext(ctx).Table(utils.GetConversationTableName(conversationID)).Where("client_msg_id = ?", msg.ClientMsgID).Updates(msg).Error; err != nil {
			log.ZError(ctx, "MarkConversationMessageAsReadDB failed", err, "msg", msg)
		} else {
			rowsAffected++
		}
	}
	return rowsAffected, nil
}

func (d *DataBase) MarkConversationAllMessageAsRead(ctx context.Context, conversationID string) (rowsAffected int64, err error) {
	d.mRWMutex.Lock()
	defer d.mRWMutex.Unlock()
	t := d.conn.WithContext(ctx).Table(utils.GetConversationTableName(conversationID)).Where("send_id != ? AND is_read == ?", d.loginUserID, false).Update("is_read", constant.HasRead)
	if t.RowsAffected == 0 {
		return 0, errs.WrapMsg(errors.New("RowsAffected == 0"), "no update")
	}
	return t.RowsAffected, errs.WrapMsg(t.Error, "UpdateMessageStatusBySourceID failed")
}

func (d *DataBase) GetMessagesByClientMsgIDs(ctx context.Context, conversationID string, msgIDs []string) (msgs []*model_struct.LocalChatLog, err error) {
	err = d.initChatLog(ctx, conversationID)
	if err != nil {
		log.ZWarn(ctx, "initChatLog err", err)
		return nil, err
	}
	d.mRWMutex.RLock()
	defer d.mRWMutex.RUnlock()
	err = errs.WrapMsg(d.conn.WithContext(ctx).Table(utils.GetConversationTableName(conversationID)).Where("client_msg_id IN ?", msgIDs).Order("send_time DESC").Find(&msgs).Error, "GetMessagesByClientMsgIDs error")
	return msgs, err
}

func (d *DataBase) GetMessagesBySeqs(ctx context.Context, conversationID string, seqs []int64) (msgs []*model_struct.LocalChatLog, err error) {
	d.mRWMutex.RLock()
	defer d.mRWMutex.RUnlock()
	err = errs.WrapMsg(d.conn.WithContext(ctx).Table(utils.GetConversationTableName(conversationID)).Where("seq IN ?", seqs).Order("send_time DESC").Find(&msgs).Error, "GetMessagesBySeqs error")
	return msgs, err
}

func (d *DataBase) GetConversationNormalMsgSeq(ctx context.Context, conversationID string) (int64, error) {
	err := d.initChatLog(ctx, conversationID)
	if err != nil {
		log.ZWarn(ctx, "initChatLog err", err)
		return 0, err
	}
	d.mRWMutex.RLock()
	defer d.mRWMutex.RUnlock()
	var seq int64
	err = d.conn.WithContext(ctx).Table(utils.GetConversationTableName(conversationID)).Select("IFNULL(max(seq),0)").Find(&seq).Error
	return seq, errs.WrapMsg(err, "GetConversationNormalMsgSeq")
}

func (d *DataBase) CheckConversationNormalMsgSeq(ctx context.Context, conversationID string) (int64, error) {
	var seq int64
	d.mRWMutex.RLock()
	defer d.mRWMutex.RUnlock()
	if d.tableChecker.HasTable(utils.GetConversationTableName(conversationID)) {
		err := d.conn.WithContext(ctx).Table(utils.GetConversationTableName(conversationID)).Select("IFNULL(max(seq),0)").Find(&seq).Error
		return seq, errs.Wrap(err)
	}
	return 0, nil
}

func (d *DataBase) GetConversationPeerNormalMsgSeq(ctx context.Context, conversationID string) (int64, error) {
	d.mRWMutex.RLock()
	defer d.mRWMutex.RUnlock()
	var seq int64
	err := d.conn.WithContext(ctx).Table(utils.GetConversationTableName(conversationID)).Select("IFNULL(max(seq),0)").Where("send_id != ?", d.loginUserID).Find(&seq).Error
	return seq, errs.WrapMsg(err, "GetConversationPeerNormalMsgSeq")
}

func (d *DataBase) UpdateMsgSenderFaceURL(ctx context.Context, sendID, faceURL string, sType int) error {
	d.mRWMutex.Lock()
	defer d.mRWMutex.Unlock()
	return errs.WrapMsg(d.conn.WithContext(ctx).Model(model_struct.LocalChatLog{}).Where(
		"send_id = ? and session_type = ? and sender_face_url != ? ", sendID, sType, faceURL).Updates(
		map[string]interface{}{"sender_face_url": faceURL}).Error, utils.GetSelfFuncName()+" failed")
}

func (d *DataBase) GetLatestActiveMessage(ctx context.Context, conversationID string, isReverse bool) (result []*model_struct.LocalChatLog, err error) {
	if err = d.initChatLog(ctx, conversationID); err != nil {
		log.ZWarn(ctx, "initChatLog err", err)
		return nil, err
	}

	d.mRWMutex.RLock()
	defer d.mRWMutex.RUnlock()

	var timeOrder string
	if isReverse {
		timeOrder = "send_time ASC"
	} else {
		timeOrder = "send_time DESC"
	}

	// only get status < 4(NotHasDeleted) Msg
	err = errs.WrapMsg(d.conn.WithContext(ctx).Table(utils.GetTableName(conversationID)).Where("status < ?", constant.MsgStatusHasDeleted).Order(timeOrder).Offset(0).Limit(1).Find(&result).Error, "GetLatestActiveMessage failed")
	if err != nil {
		return nil, err
	}

	return result, err
}
func (d *DataBase) GetLatestValidServerMessage(ctx context.Context, conversationID string, startTime int64, isReverse bool) (*model_struct.LocalChatLog, error) {
	d.mRWMutex.RLock()
	defer d.mRWMutex.RUnlock()

	var condition, timeOrder, timeSymbol string
	var result model_struct.LocalChatLog

	if isReverse {
		timeOrder = "send_time DESC"
		timeSymbol = "<"
	} else {
		timeOrder = "send_time ASC"
		timeSymbol = ">"
	}

	condition = "send_time " + timeSymbol + " ? AND seq != ?"

	err := d.conn.WithContext(ctx).Table(utils.GetTableName(conversationID)).
		Where(condition, startTime, 0).
		Order(timeOrder).
		Limit(1).
		First(&result).Error

	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, nil
		}
		return nil, errs.WrapMsg(err, "GetLatestValidServerMessage failed")
	}

	return &result, nil
}
