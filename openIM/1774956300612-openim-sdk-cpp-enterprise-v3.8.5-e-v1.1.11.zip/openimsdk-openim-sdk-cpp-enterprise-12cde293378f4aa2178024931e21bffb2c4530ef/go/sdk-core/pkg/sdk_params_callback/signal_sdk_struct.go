// Copyright © 2023 OpenIM SDK. All rights reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package sdk_params_callback

import "github.com/openimsdk/protocol/rtc"

type InviteCallback *rtc.SignalInviteResp

type InviteInGroupCallback *rtc.SignalInviteInGroupResp

type CancelCallback *rtc.SignalCancelResp

type RejectCallback *rtc.SignalRejectResp

type AcceptCallback *rtc.SignalAcceptResp

type HungUpCallback *rtc.SignalHungUpResp

type GetRoomByGroupIDCallback *rtc.SignalGetRoomByGroupIDResp

type GetTokenByRoomID *rtc.SignalGetTokenByRoomIDResp
